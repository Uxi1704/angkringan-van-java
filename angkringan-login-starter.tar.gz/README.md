# Angkringan Van Java - Login + Role Starter

## Setup

1. Buat project Next.js baru:
```bash
npx create-next-app@latest angkringan-van-java --typescript --tailwind --app
cd angkringan-van-java
npm install @supabase/supabase-js @supabase/ssr
```

2. Copy file-file dari folder ini ke project kamu.

3. Buat project di [Supabase](https://supabase.com), lalu jalankan `supabase_schema.sql` di SQL Editor.

4. Buat user di Supabase Auth (Authentication → Users → Add user).
   - Untuk owner: set role = 'owner' di user metadata saat create, atau update manual di tabel profiles.
   - Untuk kasir: role = 'kasir' + isi location_id.

5. Isi `.env.local` dari `.env.example`.

6. Jalankan:
```bash
npm run dev
```

## Struktur Role
- **Kasir**: redirect ke `/kasir/dashboard`
- **Owner**: redirect ke `/owner/dashboard`

## Next Step
Setelah login jalan, kita lanjut ke:
- Proses order
- Update stok per lokasi
- Menu management

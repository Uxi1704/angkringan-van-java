// app/owner/dashboard/page.tsx
import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'

export default async function OwnerDashboard() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) redirect('/login')

  const { data: profile } = await supabase
    .from('profiles')
    .select('role, full_name')
    .eq('id', user.id)
    .single()

  if (profile?.role !== 'owner') {
    redirect('/kasir/dashboard')
  }

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold">Dashboard Owner</h1>
      <p>Halo, {profile.full_name}</p>
      <p>Role: {profile.role}</p>
      
      <div className="mt-6 space-y-2">
        <p className="text-gray-600">Full akses:</p>
        <ul className="list-disc ml-6">
          <li>Lihat keuangan & pendapatan bulanan</li>
          <li>Stok kedua lokasi</li>
          <li>Menu paling laris</li>
          <li>Kelola semua data</li>
        </ul>
      </div>
    </div>
  )
}
